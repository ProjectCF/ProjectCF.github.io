﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <fstream>
//#define OUTPUT_FORMAT_TYPE_1
//#define OUTPUT_FORMAT_TYPE_2
#define OUTPUT_FORMAT_TYPE_3
//#define DEBUG_OUTPUT
//#define REPORT_PROGRESS
using namespace std;
typedef unsigned long long ull;
ofstream of1, of2, of3, ofd;
double* fa[1024+10];
double* f(ull i) {
    if (fa[i >> 24] == 0)fa[i >> 24] = new double[16777216];
    return fa[i >> 24] + (i & 0xffffffull);
}
void fr(ull i) {
    if (i < 256)return;
    ull j = i - 16;
    if ((j >> 24) > 1 && fa[(j >> 24) - 1]) {
        delete[] fa[(j >> 24) - 1];
        fa[(j >> 24) - 1] = 0;
    }
}
double p(ull i, ull j) {
    return min(1.0 * j * j / (2 * i - 1), 1.0);
}
void ot(ull i) {
    for (int j = 7; j >= 0; j--)of1 << ((unsigned char*)(f(i)))[j];
}
void ot2(ull i) {
    ull vi = *(ull*)f(i);
    ull vi1 = 0, vi2 = 0;
    if (i > 0)vi1 = *(ull*)(f(i - 1));
    if (i > 1)vi2 = *(ull*)(f(i - 2));
    ull tv = (vi - vi1) - (vi1 - vi2);
    ull v = (tv >> 63 ? ((0 - tv) << 1) - 1 : tv << 1);
    for (int j = 7; j >= 0; j--)of2 << (unsigned char)(v >> (j << 3));
}
unsigned char pt[9] = { 255,254,252,248,240,224,192,128,0 };
ull mv[9] = { 0xffffffffffffffffull,(1ull << 56) - 1,(1ull << 49) - 1, (1ull << 42) - 1, (1ull << 35) - 1, (1ull << 28) - 1, (1ull << 21) - 1, (1ull << 14) - 1, (1ull << 7) - 1 };
void ot3(ull i) {
    ull vi = *(ull*)f(i);
    ull vi1 = 0, vi2 = 0;
    if (i > 0)vi1 = *(ull*)(f(i - 1));
    if (i > 1)vi2 = *(ull*)(f(i - 2));
    ull tv = (vi - vi1) - (vi1 - vi2);
    ull v = (tv >> 63 ? ((0 - tv) << 1) - 1 : tv << 1);
    unsigned char arr[9] = { 0 };
    for (int j = 7; j >= 0; j--)arr[8 - j] = (unsigned char)(v >> (j << 3));
    int st = 0;
    for (int i = 0; i <= 8; i++)if (v <= mv[i])st = i;
    arr[st] += pt[st];
    for (int i = st; i <= 8; i++)of3 << arr[i];
}
int main() {
#ifdef OUTPUT_FORMAT_TYPE_3
    of3.open("3.out", ios::binary | ios::out);
#endif
#ifdef OUTPUT_FORMAT_TYPE_2
    of2.open("2.out", ios::binary | ios::out);
#endif
#ifdef OUTPUT_FORMAT_TYPE_1
    of1.open("1.out", ios::binary | ios::out);
#endif
#ifdef DEBUG_OUTPUT
    ofd.open("debug.out", ios::binary | ios::out);
#endif
    ull mr;
    cin >> mr;
#ifdef REPORT_PROGRESS
    int ro;
    cin >> ro;
#endif
#ifdef DEBUG_OUTPUT
    int de, dr;
    cin >> de >> dr;
#endif
    fa[0] = new double[16777216];
    *f(0) = 0;
    *f(1) = 1.0;
#ifdef OUTPUT_FORMAT_TYPE_3
    ot3(0);
    ot3(1);
#endif
#ifdef OUTPUT_FORMAT_TYPE_2
    ot2(0);
    ot2(1);
#endif
#ifdef OUTPUT_FORMAT_TYPE_1
    ot(0);
    ot(1);
#endif
    ull sq = 2;
    for (ull i = 2; i < (1ull << mr); i++) {
        while (sq * sq < 2 * i - 1)sq++;
        ull j = sq;
        if (j >= i)j = i - 1;
        *f(i) = (*f(i - 1) + *f(j) - (1 - p(i, j)) * (*f(i - 2))) / p(i, j);
#ifdef DEBUG_OUTPUT
        double itf = *f(i);
        if (de && i % (1ull << dr) == 0) {
            ofd << "DEBUG: calculating i=" << i << " init j=" << j << " init f=" << *f(i) << "\r\n";
        }
#endif
        j--;
        ull lf = 0;
        if (j + 1ull) {
            int ol = 0;
            do {
                ol = lf;
                lf = max(lf, (ull)ceil(sqrt((*f(i - 1) - *f(i - 2) + *f(lf)) / (*f(i) - *f(i - 2)) * (2 * i - 1))));
#ifdef DEBUG_OUTPUT
                if (de && i % (1ull << dr) == 0) {
                    ofd << "DEBUG: i=" << i << " current lf=" << lf << "\r\n";
                }
#endif
            } while (lf - ol >= 2);
            while (1) {
                double pj = p(i, j);
                *f(i) = min(*f(i), (*f(i - 1) + *f(j) - (1 - pj) * (*f(i - 2))) / pj);
#ifdef DEBUG_OUTPUT
                if (de && i % (1ull << dr) == 0) {
                    ofd << "DEBUG: i=" << i << " current j=" << j << " current f=" << *f(i) << " f difference=" << itf - *f(i) << "\r\n";
                }
#endif
                ull pos = 0;
                j--;
                if (j + 1 < lf + 1)break;
            }
        }
#ifdef OUTPUT_FORMAT_TYPE_3
        ot3(i);
#endif
#ifdef OUTPUT_FORMAT_TYPE_2
        ot2(i);
#endif
#ifdef OUTPUT_FORMAT_TYPE_1
        ot(i);
#endif
#ifdef REPORT_PROGRESS
        if (i % (1ull << ro) == 0)cout << (i >> ro) << "\n";
#endif
        fr(i);
    }
    return 0;
}
